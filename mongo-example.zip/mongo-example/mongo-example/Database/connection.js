
require('dotenv').config();
const mongoose = require('mongoose');
const LivrosSchema = require('./Models/Livros'); // Importa o modelo (tabela) que vc tem criado na sua base de dados
//const TicketsSchema = require('./Models/Usuarios'); // Exemplo, importando uma tabela Usuarios q vc criou

// escrever _____Connection
let LivrosConnection;

async function startModels()
{
    // Padrao: para conectar a base de dados
    try {
        const connection = mongoose.createConnection(process.env.DB_URL); // Connection String que pega no MongoDB
      
        connection.on('error', (err) => {
          console.error("Database connection error:", err.message);
        });
      
        connection.on('open', () => {
          console.log("Database connection established successfully.");
        });
      
        // Fazer isso para cada modelo (tabela) que tiver
        LivrosConnection = connection.model(
          'Livros',
          LivrosSchema,
          'Livros'
        );
        // -----------------------------------------------

        // Exemplo:
        // ticketsConnection = connection.model(
        //     'Usuarios',
        //     UsuariosSchema, (Ai vc cria dentro da pasta Models um modelo de Usuarios)
        //     'Usuarios'
        //   );
        // -----------------------------------------------

      } catch (error) {
        console.error("Error connecting to the database:", error);
      }
}

startModels();

module.exports = { LivrosConnection }; // Exporta para poder usar o DB em todo o codigo