// Fazer o procedimento abaixo para cada tabela que quiser criar (mudando so os nomes)


const mongoose = require('mongoose');

const Schema = mongoose.Schema;

// Mudar nome abaixo para _____Schema
const LivrosSchema = new Schema(
  {
    Titulo: { type: String, required: true },                // Mude os campos conforme preferencia de tabela
    Autor: { type: String, required: true},
    Editora: { type: String, required: true},
    Ano: { type: Number , required: true},
    Emprestado: { type: Boolean , required: true},
  }
);

module.exports = LivrosSchema;