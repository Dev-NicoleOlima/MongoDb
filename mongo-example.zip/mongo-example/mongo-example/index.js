const dbConnection = require('./Database/connection');

// --- Exemplos de como adicionar / update / remover senha (ou qualquer outro dado) ---
    
//await ticketsConnection.create({Senha: 'E001', Preferencial: false, Tipo: "Escolar", DataInicio: new Date()})
//await ticketsConnection.updateOne({Senha: 'E001'}, {Guiche: 69});
//await ticketsConnection.deleteOne({Senha: 'E001'});


// O exemplo abaixo simplesmente adiciona um novo item a tabela Tickets com as informacoes abaixo

async function CreateData()
{
    await dbConnection.LivrosConnection.create({Titulo: 'Livro1', Autor: 'nicole', Editora: "AmoMeuMor", Ano:2007 , Emprestado:false })

    console.log('Criado!');   
}

CreateData() // Chama o metodo que cria a senha

// Para roda: node index.js

// Oq precisa instalar:
// pip install mongoose
// pip install dotenv

// (dotenv eh para acessar a connection string no arquivo privado)




